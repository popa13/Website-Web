# VERDELUNE — The Lantern Road / La Route des lanternes (demo 4.2)

*Français plus bas.*

An original creature adventure with **real-time action battles**, in **3D** or **Classic 2D**, in
**English or French**. Receive your first Lumin at the Lantern Rite, have your lanterns kindled by the old
lamplighter, climb the Windbell Tower, stop the Gloam Crew in Glowmoss Grotto and earn the **Gale Badge** and the
**Chrysalis Badge**. The demo ends after the second Arena.

Everything in the game is original: the 53 Lumins, the characters, places, story, music and text.

**New in 4.2.** **Save files**: export your journey to a file (Options → Save) and import it on another computer
or browser — or keep it as a backup.

**New in 4.1.** **Cave entrances look like caves**: every way into a cave or a tunnel is now a rocky mouth —
boulders and moss around an arched opening and a passage that fades into the dark (Hollowtide Tunnel's has timber
frames, rails and a lantern; Glowmoss Grotto's glows) — and from inside, the way out shines with daylight. **The
left stick only walks; hold X (Shift on the keyboard) to run**, once Mom has given you the Trail Shoes. **Water
Lumins swim**: they ride low in the water with only the head and back above the surface, paddle, and leave ripples.

**New in 4.0 — back to voxels.** The whole game is voxel art again — the world, the people and the Lumins — in the
soft light of 3.0 (sky light, soft shadows, warm sun). **The people are the 3D model in voxels**: the Explorer is
his Meshy model voxelized (the same curly hair, scarf, jacket, cargo trousers, boots and backpack), and everyone else
is dressed from him as before — their own colours, hair, hats, beards, glasses, skirts, coats, aprons, bags and
props — with a face of their own in pixel art (eyes with a glint, brows, a smile). **The portraits beside the
dialogue** (and on the Trainer Card, in the menu, the Waylink and calls) are now voxel busts in the style of the
pictures you sent: a 3/4 view on a cream ground, warm soft light, big anime eyes, and a face that follows the mood of
the line (happy, angry, surprised, sad, thinking). **The Lumins are built from finer voxels** (8× as many): rounder
bodies, finer eyes and patterns. **The fire partner is now a fox**: **Cindling**, an ember-orange fox kit whose big
ears glow like embers, evolves into **Emberbrush** (level 16), a lanky fox with a burning brush tail, then
**Volcanid** (level 32), a great fire/rock fox under a basalt mantle cracked with magma — with fox cries of their
own (a kit's yips, a bark and a scream, a deep howl). Saves keep working (a Coalby you already have is now a
Cindling). The game file is much smaller (about 3 MB).

**3.1 — everyone has their own face.** You still play the Explorer with the face you know; every other person
now has a face of their own: the shape of the eyes (size, height, slant, spacing), nose, jaw, chin, cheeks, ears and
mouth, their own eye colour, lashes, eyelids and brows, and an age that shows (heavier lids and wrinkles for elders,
big eyes and round cheeks for children), with their freckles, glasses, beards and moustaches. Faces are alive:
people blink, glance around, move their lips while they talk and show how they feel (happy, sad, angry, surprised,
worried…). Long hair comes with a fringe of its own — straight, swept to the side, curtain bangs or brushed back —
and bald heads are smooth. The Scout has a face of their own too.

**3.0 — the film look.** The whole game uses the lighting of the style lab: soft sky light and
reflections, warm sun and rim light, colour grading, and a new world of branching trees with leaf canopies, hedges,
bushes and fields of real grass blades that bend in the wind, clearer water, sculpted rocks and boulders, darker
cave roofs that let the lit floor stand out, and new trees and stones in the battle arenas.
**The Explorer is your Meshy character** with his eight animations (idle, walk, run, jump, landing, throw, wave,
victory), in any of the six skin tones. **Every other person is dressed from the same body**: their own colours,
hair (cut short, bald, curly, afro, or with a bob, bun, ponytail, braid, twin tails, long hair…), hats, beards,
glasses, skirts, dresses, robes, lab coats, aprons, bags and hand props, with children smaller (bigger heads),
elders with age lines and grown-ups taller. The Scout is dressed the same way.

(2.0 brought the fully modelled 3D world: buildings, interiors, props, caves and the 3D battle arenas.)

## Start the game

The whole game is one file, **`Verdelune.html`**. No installation, no internet connection needed.

| System | How to start |
|---|---|
| Linux | `sh Play-Verdelune-Linux.sh`, or open `Verdelune.html` in Firefox / Chrome / Chromium / Edge |
| Windows | double-click `Play-Verdelune-Windows.bat` (opens Edge), or open `Verdelune.html` in Edge / Chrome |
| macOS | double-click `Play-Verdelune-macOS.command` (first time: right-click → Open; if macOS says it can't be run, type `chmod +x Play-Verdelune-macOS.command` in Terminal), or open `Verdelune.html` in Chrome / Safari |

Recommended browsers: **Chrome, Chromium, Edge or Firefox**. On Linux, an Xbox controller connected by Bluetooth in
Firefox (right stick and triggers reported on the wrong inputs by the browser) is detected and corrected automatically.

### Xbox controller
1. Pair or plug in the controller, then **press any button** once the game is open (browsers only reveal a pad
   after a button press).
2. **Menu → Options → Controls** shows every binding, lets you **remap** the controller and the keyboard, and has a
   **controller tester** that lights up every button, stick and trigger live. If something does nothing, check it
   there first.
- Linux (Bluetooth / xpadneo), Windows and macOS layouts are detected automatically, including pads that report a
  non-standard layout. Triggers that report a false "half pressed" value before first use are ignored.
- Sound starts after your first click or key press (browser rule). If you only use the pad, click once in the window.

## Controls

### Battles (real time)
| Action | Xbox controller | Keyboard |
|---|---|---|
| Move freely | Left stick / D-pad | Arrow keys |
| Moves 1 · 2 · 3 · 4 | **A · B · X · Y** | **A · S · Q · W** |
| Jump (×2, Flying types ×4) | **RT** | **E** |
| Guard (hold — blocks hits from the front) | **LB** | **Shift** |
| Dodge (quick dash, invulnerable) | **LT** | **Space** |
| Menu / Bag (pauses: Fight · Bag · Lumins · Run) | **Menu ≡** | **Tab** |
| Camera (3D) | Right stick | Right-mouse drag · **,** **.** |
| Camera back behind your Lumin | click the right stick (**R3**) | **R** |
| Zoom | Hold **RB** + right stick ↑/↓ | Mouse wheel · **+** **−** |

The battle camera follows your Lumin and turns, tilts and zooms only when you move it. Face your opponent to land a hit. Watch the red warning cards: when a foe winds up an attack you have time to
guard, dodge or jump. To befriend a wild Lumin, weaken it, then **Menu → Bag → Lanterns** (choose with the D-pad /
left stick or the arrow keys, throw with **A** / **Enter**).

### Exploring
| Action | Xbox controller | Keyboard |
|---|---|---|
| Move | Left stick / D-pad | Arrows or WASD |
| Talk / interact | **A** | Space / Enter |
| Cancel / back | **B** | Esc / Backspace |
| Run (after you get the Trail Shoes — the stick alone walks) | hold **X** | hold Shift |
| Waylink (map, contacts) | **Y** | M |
| Bag | **LB** | B |
| Main menu | **Menu ≡** | Tab |
| Journey Journal | **View ⧉** | J |
| Camera / zoom (3D) | Right stick · **RB** + right stick | Right-drag / , . · wheel |
| First-person view (3D) | click the right stick (R3) | V |

Arena Leaders and the Bell Warden wait for you: walk up to them and talk to them (**A** / Enter) to start the challenge.

## Options
- **Display mode:** 3D or Classic 2D (pixel-art presentation of the same world and battles).
- **Language:** English / Français (also on the title screen).
- **Day & night:** follows your local time, or pick Morning / Day / Evening / Night.
- Wild Lumin density, text speed, camera, volumes, graphics quality, battle hints.
- The game auto-saves at key moments and in every Refuge; you can also save from the menu. Saves live in the
  browser you play with — use the same browser to continue.
- **Save files:** Options → **Save** → **Export my journey** downloads your journey as a file
  (`verdelune-<name>-<date>.vlsave`, in your Downloads). On another computer or browser, **Import a journey**
  (in the same place, or on the title screen) and choose the file — or drop the file onto the game window. Keep an
  exported file as a backup too: clearing the browser's data erases the journey saved in it.

## Troubleshooting
- **Black screen / "WebGL2 not available":** enable hardware acceleration in the browser settings, then reload.
- **Slow:** Options → Graphics → Low or Medium (or lower the resolution scale). The first visit to an area builds
  its 3D models, which can take a few seconds on slower computers; coming back is quicker.
- **Controller not detected:** press a button while the game window is focused; check Options → Controls → tester.
- **A stick or trigger does the wrong thing:** Options → Controls → Controller tester → **Setup wizard**, then press
  each button and move each stick when asked. **Reset controller mapping** goes back to the automatic layout.

## Source code
`Verdelune-source.zip` holds the full source (plain JavaScript modules, no engine or library). To rebuild
`Verdelune.html`: unzip, then `npm install` and `npm run build` (Node 18+) — the result is `dist/Verdelune.html`.
To play from the sources, serve the folder (`npm run serve`) and open `http://localhost:8090/index.html`.

---

# VERDELUNE — La Route des lanternes (démo 3.1)

Une aventure de créatures originale avec des **combats en temps réel**, en **3D** ou en **2D classique**,
en **français ou en anglais**. Recevez votre premier Lumin lors du Rite des lanternes, faites allumer vos
lanternes par la vieille allumeuse, gravissez la Tour de la Cloche-Vent, arrêtez le Clan Pénombre dans la
Grotte de Luimousse et gagnez le **Badge Rafale** et le **Badge Chrysalide**. La démo se termine après la deuxième Arène.

Tout est original : les 53 Lumins, les personnages, les lieux, l'histoire, la musique et les textes.

**Nouveau dans la 4.2.** **Fichiers de sauvegarde** : exportez votre voyage dans un fichier (Options → Sauvegarde)
et importez-le sur un autre ordinateur ou navigateur — ou gardez-le en copie de secours.

**Nouveau dans la 4.1.** **Les entrées de grottes ressemblent enfin à des grottes** : chaque passage vers une grotte
ou un tunnel est maintenant une bouche rocheuse — des rochers et de la mousse autour d'une ouverture en arche, un
couloir qui s'enfonce dans le noir (celui du Tunnel de Creuse-Marée a des étais en bois, des rails et une lanterne ;
celui de la Grotte de Luimousse luit) — et de l'intérieur, la sortie brille de la lumière du jour. **Le stick gauche
fait seulement marcher ; maintenez X (Maj au clavier) pour courir**, une fois que Maman vous a donné les Chaussures
de sentier. **Les Lumins aquatiques nagent** : ils flottent bas dans l'eau, seuls la tête et le dos dépassent, ils
pagaient et laissent des ronds dans l'eau.

**Nouveau dans la 4.0 — retour aux voxels.** Tout le jeu est de nouveau en voxels — le monde, les personnages et les
Lumins — dans la lumière douce de la 3.0 (lumière du ciel, ombres douces, soleil chaud). **Les personnages sont le
modèle 3D en voxels** : l'Explorateur·rice est son modèle Meshy voxélisé (mêmes cheveux bouclés, foulard, veste,
pantalon cargo, bottes et sac à dos), et tous les autres sont habillés à partir de lui comme avant — leurs couleurs,
coiffures, chapeaux, barbes, lunettes, jupes, manteaux, tabliers, sacs et accessoires — avec un visage à eux en pixel
art (des yeux qui brillent, des sourcils, un sourire). **Les portraits à côté des dialogues** (et sur la carte de
dresseur, dans le menu, le Waylink et les appels) sont maintenant des bustes en voxels dans le style des images que
tu as envoyées : vue de trois quarts sur fond crème, lumière douce et chaude, grands yeux d'anime, et un visage qui
suit l'humeur de la réplique (joie, colère, surprise, tristesse, réflexion). **Les Lumins sont faits de voxels plus
fins** (8 fois plus nombreux) : corps plus ronds, yeux et motifs plus fins. **Le partenaire Feu est maintenant un
renard** : **Cindling**, un renardeau orange braise dont les grandes oreilles rougeoient, évolue en **Emberbrush**
(niveau 16), un renard élancé à la queue en brosse enflammée, puis en **Volcanid** (niveau 32), un grand renard
Feu/Roche sous un manteau de basalte fissuré de magma — avec des cris de renard bien à eux (les jappements du
renardeau, un aboiement et un glapissement, un hurlement grave). Les sauvegardes restent valables (un Coalby déjà
capturé est maintenant un Cindling). Le fichier du jeu est bien plus léger (environ 3 Mo).

**3.1 — chacun son visage.** Tu joues toujours l'Explorateur·rice avec son propre visage ; tous les
autres personnages ont maintenant un visage à eux : la forme des yeux (taille, hauteur, inclinaison, écart), du nez,
de la mâchoire, du menton, des joues, des oreilles et de la bouche, leur couleur d'yeux, leurs cils, paupières et
sourcils, et un âge qui se voit (paupières plus lourdes et rides pour les aînés, grands yeux et joues rondes pour les
enfants), avec leurs taches de rousseur, lunettes, barbes et moustaches. Les visages sont vivants : les gens clignent
des yeux, regardent autour d'eux, bougent les lèvres quand ils parlent et montrent ce qu'ils ressentent (joie,
tristesse, colère, surprise, inquiétude…). Les cheveux longs ont leur propre frange — droite, de côté, rideau ou
coiffée en arrière — et les crânes chauves sont lisses. L'Éclaireur·se a aussi son propre visage.

**3.0 — le rendu « film ».** Tout le jeu utilise l'éclairage du laboratoire de style :
lumière douce du ciel et reflets, soleil chaud et lumière de contour, étalonnage des couleurs, et un nouveau monde
d'arbres ramifiés aux feuillages denses, de haies, de buissons et de prairies de vrais brins d'herbe qui ploient au
vent, une eau plus limpide, des rochers sculptés, des voûtes de grotte plus sombres qui font ressortir le sol
éclairé, et de nouveaux arbres et rochers dans les arènes. **L'Explorateur·rice est ton personnage Meshy** avec ses
huit animations (repos, marche, course, saut, réception, lancer, salut, victoire), dans les six teintes de peau.
**Tous les autres personnages sont habillés à partir du même corps** : leurs couleurs, leur coiffure (courte,
chauve, bouclée, afro, ou avec carré, chignon, queue-de-cheval, tresse, couettes, cheveux longs…), chapeaux, barbes,
lunettes, jupes, robes, toges, blouses, tabliers, sacs et accessoires en main ; les enfants sont plus petits (tête
plus grosse), les aînés ont des rides et les adultes sont plus grands. L'Éclaireur·se est habillé·e de la même façon.

(La 2.0 avait apporté le monde entièrement modélisé en 3D : bâtiments, intérieurs, objets, grottes et arènes 3D.)

Le jeu tient dans un seul fichier, **`Verdelune.html`**. Aucune installation, aucune connexion Internet.

| Système | Lancement |
|---|---|
| Linux | `sh Play-Verdelune-Linux.sh`, ou ouvrir `Verdelune.html` dans Firefox / Chrome / Chromium / Edge |
| Windows | double-cliquer sur `Play-Verdelune-Windows.bat` (ouvre Edge), ou ouvrir `Verdelune.html` dans Edge / Chrome |
| macOS | double-cliquer sur `Play-Verdelune-macOS.command` (la première fois : clic droit → Ouvrir ; si macOS refuse de l'exécuter, tapez `chmod +x Play-Verdelune-macOS.command` dans le Terminal), ou ouvrir `Verdelune.html` dans Chrome / Safari |

Navigateurs conseillés : **Chrome, Chromium, Edge ou Firefox**. Sous Linux, une manette Xbox connectée en Bluetooth
dans Firefox (stick droit et gâchettes transmis sur les mauvaises entrées par le navigateur) est détectée et corrigée
automatiquement.

### Manette Xbox
1. Connectez la manette (USB ou Bluetooth), puis **appuyez sur un bouton** une fois le jeu ouvert (les navigateurs
   ne détectent la manette qu'après une pression).
2. **Menu → Options → Commandes** affiche toutes les commandes, permet de **réassigner** la manette et le clavier,
   et contient un **testeur de manette** qui allume chaque bouton, stick et gâchette en direct. Si quelque chose
   ne répond pas, vérifiez d'abord là.
- Les dispositions Linux (Bluetooth / xpadneo), Windows et macOS sont détectées automatiquement, y compris les
  manettes non standard. Les gâchettes qui indiquent une fausse valeur « à moitié enfoncée » avant la première
  utilisation sont ignorées.
- Le son démarre après le premier clic ou la première touche (règle des navigateurs). Avec la manette seule,
  cliquez une fois dans la fenêtre.

## Commandes

### Combats (temps réel)
| Action | Manette Xbox | Clavier |
|---|---|---|
| Se déplacer librement | Stick gauche / croix | Flèches |
| Capacités 1 · 2 · 3 · 4 | **A · B · X · Y** | **A · S · Q · W** |
| Sauter (×2, type Vol ×4) | **RT** | **E** |
| Se protéger (maintenir — bloque les coups de face) | **LB** | **Maj** |
| Esquiver (ruée rapide, invulnérable) | **LT** | **Espace** |
| Menu / Sac (pause : Combat · Sac · Lumins · Fuite) | **Menu ≡** | **Tab** |
| Caméra (3D) | Stick droit | Clic droit + glisser · **,** **.** |
| Caméra derrière votre Lumin | clic du stick droit (**R3**) | **R** |
| Zoom | Maintenir **RB** + stick droit ↑/↓ | Molette · **+** **−** |

La caméra de combat suit votre Lumin et ne tourne, ne s'incline et ne zoome que lorsque vous la bougez. Faites face à votre adversaire pour le toucher. Surveillez les cartes d'alerte : quand un adversaire prépare une
attaque, vous avez le temps de vous protéger, d'esquiver ou de sauter. Pour apprivoiser un Lumin sauvage,
affaiblissez-le puis **Menu → Sac → Lanternes** (choisissez avec la croix / le stick gauche ou les flèches, lancez
avec **A** / **Entrée**).

### Exploration
| Action | Manette Xbox | Clavier |
|---|---|---|
| Se déplacer | Stick gauche / croix | Flèches ou ZQSD/WASD |
| Parler / interagir | **A** | Espace / Entrée |
| Annuler / retour | **B** | Échap / Retour arrière |
| Courir (après les Chaussures de sentier — le stick seul fait marcher) | maintenir **X** | maintenir Maj |
| Waylink (carte, contacts) | **Y** | M |
| Sac | **LB** | B |
| Menu principal | **Menu ≡** | Tab |
| Carnet de voyage | **Affichage ⧉** | J |
| Caméra / zoom (3D) | Stick droit · **RB** + stick droit | Clic droit / , . · molette |
| Vue à la première personne (3D) | clic du stick droit (R3) | V |

Les chefs d'arène et le Gardien de la cloche vous attendent : approchez-vous et parlez-leur (**A** / Entrée) pour les défier.

## Options
- **Mode d'affichage :** 3D ou 2D classique (présentation pixel art du même monde et des mêmes combats).
- **Langue :** Français / English (aussi sur l'écran titre).
- **Jour et nuit :** suit l'heure locale, ou choisissez Matin / Jour / Soir / Nuit.
- Densité des Lumins sauvages, vitesse du texte, caméra, volumes, qualité graphique, aides de combat.
- Sauvegarde automatique aux moments clés et dans chaque Refuge ; sauvegarde possible depuis le menu. Les
  sauvegardes sont stockées dans le navigateur utilisé : reprenez avec le même navigateur.
- **Fichiers de sauvegarde :** Options → **Sauvegarde** → **Exporter mon voyage** télécharge votre voyage dans un
  fichier (`verdelune-<nom>-<date>.vlsave`, dans vos Téléchargements). Sur un autre ordinateur ou navigateur,
  **Importer un voyage** (au même endroit, ou sur l'écran titre) et choisissez le fichier — ou déposez-le sur la
  fenêtre du jeu. Gardez aussi un fichier exporté en copie de secours : effacer les données du navigateur efface le
  voyage qui y est sauvegardé.

## Dépannage
- **Écran noir / « WebGL2 indisponible » :** activez l'accélération matérielle du navigateur, puis rechargez.
- **Lenteurs :** Options → Graphismes → Basse ou Moyenne (ou baissez l'échelle de résolution). La première visite
  d'une zone construit ses modèles 3D, ce qui peut prendre quelques secondes sur un ordinateur lent ; y revenir
  est plus rapide.
- **Manette non détectée :** appuyez sur un bouton avec la fenêtre du jeu active ; vérifiez Options → Commandes → testeur.
- **Un stick ou une gâchette fait la mauvaise action :** Options → Commandes → Testeur de manette → **Assistant de
  configuration**, puis appuyez sur chaque bouton et bougez chaque stick à la demande. **Réinitialiser la
  configuration** revient à la disposition automatique.

## Code source
`Verdelune-source.zip` contient tout le code source (modules JavaScript, sans moteur ni bibliothèque). Pour
reconstruire `Verdelune.html` : décompressez, puis `npm install` et `npm run build` (Node 18+) — le résultat est
`dist/Verdelune.html`. Pour jouer depuis les sources, servez le dossier (`npm run serve`) et ouvrez
`http://localhost:8090/index.html`.
