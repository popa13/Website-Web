#!/bin/sh
# Verdelune — Linux launcher. Opens the game in Chrome / Chromium / Edge / Brave if one is installed, otherwise in
# Firefox, otherwise in your default browser.
# Lanceur Linux : ouvre le jeu dans Chrome/Chromium/Edge/Brave s'il est installé, sinon dans Firefox.
DIR="$(cd "$(dirname "$0")" && pwd)"
URL="file://$DIR/Verdelune.html"
for b in google-chrome google-chrome-stable chromium chromium-browser microsoft-edge brave-browser; do
  if command -v "$b" >/dev/null 2>&1; then exec "$b" --new-window "$URL"; fi
done
# Firefox next (Bluetooth Xbox pads are corrected automatically); Flatpak browsers last (sandboxed: a controller or
# the game folder may be out of their reach).
if command -v firefox >/dev/null 2>&1; then exec firefox --new-window "$URL"; fi
if command -v flatpak >/dev/null 2>&1; then
  for app in org.mozilla.firefox com.google.Chrome org.chromium.Chromium com.brave.Browser com.microsoft.Edge; do
    if flatpak info "$app" >/dev/null 2>&1; then exec flatpak run "$app" --new-window "$URL"; fi
  done
fi
exec xdg-open "$URL"
