@echo off
rem Verdelune - Windows launcher: opens the game in Microsoft Edge (built into Windows) or Chrome,
rem otherwise in your default browser.  /  Lanceur Windows : ouvre le jeu dans Edge ou Chrome.
set "GAME=%~dp0Verdelune.html"
where msedge >nul 2>nul && (start "" msedge --new-window "%GAME%" & exit /b)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --new-window "%GAME%" & exit /b)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --new-window "%GAME%" & exit /b)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --new-window "%GAME%" & exit /b)
start "" "%GAME%"
