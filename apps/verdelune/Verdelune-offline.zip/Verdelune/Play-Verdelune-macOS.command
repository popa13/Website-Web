#!/bin/sh
# Verdelune — macOS launcher: Chrome or Edge if installed (best controller support), otherwise Safari / default.
# Lanceur macOS : Chrome ou Edge si installés, sinon Safari. (Première fois : clic droit → Ouvrir.)
DIR="$(cd "$(dirname "$0")" && pwd)"
GAME="$DIR/Verdelune.html"
if [ -d "/Applications/Google Chrome.app" ]; then open -na "Google Chrome" --args --new-window "file://$GAME"; exit 0; fi
if [ -d "/Applications/Microsoft Edge.app" ]; then open -na "Microsoft Edge" --args --new-window "file://$GAME"; exit 0; fi
open "$GAME"
